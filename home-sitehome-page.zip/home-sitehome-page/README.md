# Home site - home page

A Pen created on CodePen.io. Original URL: [https://codepen.io/erids23/pen/LYJrzjq](https://codepen.io/erids23/pen/LYJrzjq).

Home page for personal website